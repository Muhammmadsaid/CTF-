#!/usr/bin/python

def dfg(efg):
    return ''.join(chr(int(efg[i:i+2], 16)) for i in range(0, len(efg), 2))

def display_challenge_description():
    description = """
==========================================
   🌟 2-CHALLENGE: HASKERSGA QO'SHILDI! 🌟
==========================================

Qoyil, siz darrov 2-challenge ga yetib keldingiz, 
o'ylaymanki bu challenge siz uchun hech qanday muammo 
tug'dirmaydi, chunki siz **hacker** siz 😊

Flag tayyor `Flag.txt` file ichida joylashgan, lekin uni 
James dan boshqa hech kim ochib ko'ra olmadi. Lekin men 
sizni qo'lingizdan kelishiga 100% aminman.

------------------------------------------

💡 **Hint**: 
James kotta bolla ni gruhida, balki shuning uchun u 
ko'p ishga qodirdir...

------------------------------------------

Keep up the good work and happy hacking!

==========================================
"""

    print(description)

def main():
    efg = ''.join(f'{ord(c):02x}' for c in 'Avatar{google_and_grep_4_the_win}')

    might = dfg(efg)
    user_input = input("2-challenge ga o'tish uchun 1-flagni kiriting: ")
    if user_input.strip() == might:
        display_challenge_description()
    else:
        print("❌ Noto'g'ri flag, qaytadan urining!!!")
if __name__ == "__main__":
    main()

