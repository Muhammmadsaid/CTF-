#!/usr/bin/env python3
import os

def read_file(filepath):
    """Read the contents of a file and return it as a string."""
    with open(filepath, 'r') as file:
        return file.read().strip()

def main():
    # File paths
    password_file = "/home/for_ctf/CTF/challenge5/.frucrt/.lg130.txt"
    flag_file = "/home/for_ctf/CTF/challenge5/.bashrc/.f{1-100}.txt"
    correct_password = read_file(password_file)
    entered_password = input("Enter the password to retrieve the flag:\n> ").strip()
    if entered_password == correct_password:
        if os.path.exists(flag_file):
            flag = read_file(flag_file)
            print("\nPassword is correct. Here is your flag:")
            print("********************************************")
            print(flag)
            print("********************************************")
        else:
            print("\nFlag file does not exist.")
    else:
        print("\nIncorrect password. Access denied.")
        print("Please try again!")

if __name__ == "__main__":
    main()

