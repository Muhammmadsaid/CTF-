#!/usr/bin/env python3

import base64

def main():

    obfuscated_password = "bWVnYW1pbmQxMDI5"
    correct_password = base64.b64decode(obfuscated_password).decode('utf-8')
    
    entered_password = input("Enter the password to retrieve the flag:\n> ").strip()
    
    if entered_password == correct_password:
        obfuscated_flag = "RmxhZ3tZb3VfYXJlX01lZ2FNaW5kIX0="
        flag = base64.b64decode(obfuscated_flag).decode('utf-8')
        
        print("Siz haqiqatdan ham Megamind siz, va bu sizning Flagingiz: ")
        print(flag)
    else:
        print("Noto'g'ri, qaytadan urining!!!")

if __name__ == "__main__":
    main()

