#!/usr/bin/env python3

import base64

def ask_question(question, correct_answer):
    answer = input(question + "\n> ").strip()
    return answer.lower() == correct_answer.lower()

def main():
    print("Welcome to Challenge 4! Please answer the following questions to get the password.")
    
    questions = [
        ("What is the command to list files in a directory?", "ls"),
        ("Which command is used to change the current directory?", "cd"),
        ("How do you create a new user in Linux?", "useradd"),
        ("What is the command to change ownership of a file?", "chown"),
        ("Which command is used to display the Unix version?", "uname -a"),
        ("Which one is more modern: zsh or bash?", "zsh"),
        ("2 != R in File permission: True or False", "true"),
        ("What command displays the path for the current directory?", "pwd"),
        ("Special command to search a specific string?", "grep")
    ]
    
    for question, correct_answer in questions:
        if not ask_question(question, correct_answer):
            print("Wrong answer. Try again.")
            return

    # Obfuscated password (base64 encoded)
    obfuscated_password = "bWVnYW1pbmQxMDI5"
    password = base64.b64decode(obfuscated_password).decode('utf-8')
    
    print("All answers are correct. Here is your password:")
    print(password)

if __name__ == "__main__":
    main()

